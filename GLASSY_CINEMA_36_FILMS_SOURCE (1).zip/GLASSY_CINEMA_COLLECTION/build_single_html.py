"""Bundle FRAME into one fully portable HTML file with offline concept-art fallbacks."""
from pathlib import Path
import base64, json, re
root=Path(__file__).resolve().parent
s=(root/'index.html').read_text(encoding='utf8')
css=(root/'styles.css').read_text(encoding='utf8')
js=(root/'app.js').read_text(encoding='utf8')
assets={p.stem:'data:image/webp;base64,'+base64.b64encode(p.read_bytes()).decode('ascii') for p in sorted((root/'assets').glob('*.webp'))}
for key,data in assets.items():
    css=css.replace('assets/'+key+'.webp',data)
    s=s.replace('assets/'+key+'.png',data)
js=js.replace("const fallback=(movie)=>`assets/${ART_BY_FILM[movie.id] || FALLBACKS[movie.index%6]}.webp`;", "const fallback=(movie)=>window.FRAME_FALLBACKS[ART_BY_FILM[movie.id] || FALLBACKS[movie.index%6]];")
s=s.replace('<link rel="stylesheet" href="styles.css" />','<style>'+css+'</style>')
s=s.replace('<script src="app.js"></script>', '<script>window.FRAME_FALLBACKS='+json.dumps(assets,separators=(',',':'))+';</script><script>'+js+'</script>')
out=root.parent/'GLASSY_CINEMA_36_FILMS_ENGLISH.html'
out.write_text(s,encoding='utf8')
print('Wrote',out,'size',out.stat().st_size)
