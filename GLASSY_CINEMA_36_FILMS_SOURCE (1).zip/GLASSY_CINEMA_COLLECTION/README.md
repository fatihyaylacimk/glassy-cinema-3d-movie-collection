# FRAME — Glassy Cinema | 36 Films, 6 Collections

FRAME is a responsive, English-language movie discovery showcase inspired by a cinematic scroll-based design. It is a static website, **not** a streaming service or a native Android/iOS app.

## What's inside

- Animated central 3D/glassy movie showcase with five rotating featured films.
- Six horizontally swipeable collections with **six movies each** (36 total).
- Additional full-library section with 36 cards and category filters.
- Movie details dialogs with synopsis, release year, runtime and genre.
- Live search by title, genre, year or collection.
- Browser-based watchlist using `localStorage` (no account required).
- Mobile-first layout, desktop navigation, scrolling reveal animations and motion accessibility preferences.
- External promotional poster requests through TMDB's public image CDN. **If an image cannot load**, the site displays one of six bundled, original concept-art images. The original PNGs and compressed WebP versions are included in the `assets/` folder.
- The "Find trailer" control opens a YouTube search, not an embedded licensed trailer.

## Film collections

| Collection | Films |
| --- | --- |
| Sci-Fi & Space | Interstellar, Dune: Part Two, Blade Runner 2049, Inception, The Martian, Arrival |
| Action & Thriller | The Dark Knight, The Batman, John Wick: Chapter 4, Top Gun: Maverick, Mad Max: Fury Road, Mission: Impossible – Fallout |
| Fantasy & Adventure | Avatar: The Way of Water, The Return of the King, Harry Potter and the Prisoner of Azkaban, Pirates of the Caribbean: The Curse of the Black Pearl, Jurassic Park, The Hobbit: An Unexpected Journey |
| Cinematic Masterpieces | Oppenheimer, The Shawshank Redemption, Gladiator, Fight Club, The Prestige, The Matrix |
| Mystery & Suspense | Se7en, Shutter Island, Gone Girl, Prisoners, The Silence of the Lambs, Nightcrawler |
| Animation & Wonder | Spider-Man: Into the Spider-Verse, Spider-Man: Across the Spider-Verse, WALL·E, Soul, Coco, Howl's Moving Castle |

## Open the website

**Option 1 — Single-file HTML:** Open `GLASSY_CINEMA_36_FILMS_ENGLISH.html` in a modern browser. The local fallback artwork is embedded directly. You can copy the file to a phone and open it with Chrome, Safari or another modern browser that supports local HTML files.

**Option 2 — Source-code folder:** Run a basic static local server inside this source folder, then open the localhost address in your browser:

```bash
python -m http.server 8000
```

**Option 3 — Publish online:** Upload `index.html`, `styles.css`, `app.js` and `assets/` to a static hosting provider.

## Rights and limitations

- FRAME is an independent visual film-discovery prototype and **does not host or stream feature films**.
- Movie names and synopsis descriptions are used for discovery. Promotional movie poster imagery may have copyright or other usage restrictions; check permissions or licenses before a public or commercial launch.
- If the TMDB image CDN is inaccessible, the bundled original illustrations appear in place of movie posters. The design is usable offline, but real film posters are not bundled.
- This is not sponsored or endorsed by The Movie Database (TMDB), any film studio, or a streaming service.
- This prototype has no backend, subscriptions, or user authentication. The watchlist is saved in the current browser only.

## Tech stack

HTML5, CSS3, vanilla JavaScript, browser `localStorage` and Canvas. No package installation, bundler or API key is required. `build_single_html.py` recreates the portable HTML build and embeds the local illustrations.
